"""Executable manuscript cases."""
